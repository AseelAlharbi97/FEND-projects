/* Global Variables */
const key = "919234510b8d027002f20b6f66676574";

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();

const generate=document.getElementById('generate')
generate.addEventListener('click',weatherdata)

async function weatherdata(){

    let feelings=document.getElementById('feelings').value;
    let zipcode=document.getElementById('zip').value;

    let data = await fetch('http://api.openweathermap.org/data/2.5/weather?zip='+zipcode+'&appid=919234510b8d027002f20b6f66676574')
    let respon = await data.json()
    console.log(respon);

    let obj = { 
      date: newDate,
      feel: feelings,
      temp: respon.main.temp,
    }

    const response = await fetch('http://localhost:8000/postweather', {
        method: 'POST', 
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(obj) 
    })

     data= await fetch('http://localhost:8000/getweather')
     let responed = await data.json() 
     console.log(responed);

      document.getElementById('temp').innerHTML= responed.temp
      document.getElementById('content').innerHTML= responed.feel
      document.getElementById('date').innerHTML= responed.date
}

