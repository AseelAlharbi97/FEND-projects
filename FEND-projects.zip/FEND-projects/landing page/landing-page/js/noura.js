 

/**

 * Define Global Variables

 * 

*/

const navbar = document.querySelector('#navbar__list');

const sections = document.querySelectorAll('section');

/**

 * End Global Variables

 * Start Helper Functions

 * 

*/




/**

 * End Helper Functions

 * Begin Main Functions

 * 

*/

 

// build the nav 

for (let i = 1; i <= 4; i++) {

  const var1 = document.createElement("li");

  const var2 = document.createElement("a");

  var2.textContent = "Section " + i;

  var2.setAttribute("href", "#section" + i);

  var1.appendChild(var2);

  const navChild = var1.outerHTML;

  navbar.insertAdjacentHTML("beforeend", navChild);

}

  

 

onscroll = function () {

  let scrollPosition = document.documentElement.scrollTop;

  sections.forEach((section) => {

 

    if (

      scrollPosition >= section.offsetTop 

    ) {

      let currentId = section.attributes.id.value;

      removeAllActiveClasses();

      addActiveClass(currentId);

    }

  });

};

 

let removeAllActiveClasses = function () {

  document.querySelectorAll("nav a").forEach((el) => {

    el.classList.remove("active");

  });

};

 

let addActiveClass = function (id) {

  var selector = `nav a[href="#${id}"]`;

  document.querySelector(selector).classList.add("active");

};

 

var navLinks = document.querySelectorAll("nav a");

 

navLinks.forEach((link) => {

  link.addEventListener("click", (e) => {

    e.preventDefault();

    let currentId = e.target.attributes.href.value;

    let section = document.querySelector(currentId);

    let sectionPos = section.offsetTop;

    window.scroll({

      top: sectionPos,

      behavior: "smooth",

    });

  });

});