# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

this file contain multilabel files , HTML, js , css .

html contains 4 section with prographs . every section has ID # can be easily modified when using css or Js



## Description

the most job were don and Js .

created function for nav to make it show or disapper , 
depends on user activity  , made it easy to access when use navbar bouton to go to the required section fast and smoothly ;


## Support

give me good review :D ;

