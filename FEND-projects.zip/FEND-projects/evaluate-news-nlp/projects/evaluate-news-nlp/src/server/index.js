const dotenv = require("dotenv");
dotenv.config();
var path = require("path");
const express = require("express");
const mockAPIResponse = require("./mockAPI.js");
var bodyParser = require("body-parser");
var cors = require("cors");
let fetch = require("node-fetch");
var json = {
  title: "test json response",
  message: "this is a message",
  time: "now",
};

const app = express();
app.use(cors());
// to use json
app.use(bodyParser.json());
// to use url encoded values
app.use(
  bodyParser.urlencoded({
    extended: false,
  })
);

app.use(express.static("dist"));
// here is the api key and the obj "yourdata"
let yourdata = {};
const API_KEY = process.env.API_KEY;

// getting the url and key from the meaningcloud
let THELINK = "https://api.meaningcloud.com/sentiment-2.1?";


// post route
app.post("/sendLink", async function (req, res) {
  console.log("I am inside link");
  let yourlink = req.body.Link;
  console.log("link:", yourlink);
  let link = `${THELINK}key=${API_KEY}&url=${yourlink}&lang=en`;
  // here is fetch
  let answer = await fetch(link);
  let r = await answer.json();
  console.log("GREAT!");
  console.log(r);

  //declare variables and get values
  let agreement = r.agreement;
  let confidence = r.confidence;
  let subjectivity = r.subjectivity;
  let irony = r.irony;

  // here i fill the obj
  yourdata = {
    agreement: agreement,
    confidence: confidence,
    subjectivity: subjectivity,
    irony: irony,
  };
  //print success and send it back
  console.log("YESSS!");
  console.log(yourdata);
  res.send(yourdata);
});
console.log(JSON.stringify(mockAPIResponse));

app.get("/", function (req, res) {
  res.sendFile("dist/index.html");
});

app.get("/test", function (req, res) {
  res.send(mockAPIResponse);
});


app.listen(8081, function () {
  console.log("Example app listening on port 8081!");
});