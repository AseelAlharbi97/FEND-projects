import { testing } from "./js/nameChecker";
import { handleSubmit } from "./js/Handler";

import "./styles/resets.scss";
import "./styles/base.scss";
import "./styles/form.scss";
import "./styles/footer.scss";
import "./styles/header.scss";


let s = document.querySelector(".submit");
s.addEventListener("click", (e) => {
  handleSubmit(e);
});

export { testing, handleSubmit };
