// here is the function to check the link and return result 

function testing(LINK) {
    let checking = LINK.match(
      /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g
    );
    // if the checking == null do this 
    if (checking == null) {
      return false;
    } else {
      return true;
    }
  }
  // Finally here is the export ..
  export { testing };
