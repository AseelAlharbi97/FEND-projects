// here i am done with the function to get ..
async function getmethodd(LINK, d) {
    let response = await fetch(LINK, {
      method: "POST",
      credentials: "same-origin",
      mode: "cors",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(d),
    });
    // try and catch for the error
    try {
      let r = await response.json();
      console.log(r);
      return r;
    } catch (e) {
      console.log("Error!!!");
    }
  }
  
  //update the UI of user
  export function updateUI(data) {
    //declacre variables
    const confidence = document.querySelector(".firstclass");
    const subjectivity = document.querySelector(".secondclass");
    const agreement = document.querySelector(".thirdclass");
    const irony = document.querySelector(".forthclass");
  
    // update the UI
    agreement.innerHTML = `Agreement :  ${data["agreement"]}`;
    confidence.innerHTML = `Confidence :  ${data["confidence"]}`;
    subjectivity.innerHTML = `Subjectivity : ${data["subjectivity"]}`;
    irony.innerHTML = `Irony : ${data["irony"]}`;
  }
  
  // this is the function of handling sumbit event
  function handleSubmit(event) {
    event.preventDefault();
    //get the link from the user
    const LINK = document.getElementById("name").value;
    // HERE is IF CONDTION !
    if (Client.testing(LINK)) {
      console.log("Great!!!");
      // I USE PORT 8081
      getmethodd("http://localhost:8081/sendLink", {
        Link: LINK,
      }).then(
        (d) => updateUI(d)
      );
    }
  }
  
  // finally here export the handling submit
  export { handleSubmit };
