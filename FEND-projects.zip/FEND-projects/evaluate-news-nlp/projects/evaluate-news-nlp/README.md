it requires you to build a web tool that allows users to run  (NLP) on articles
The goal of this project is
1- Setting up Webpack and sass
2- Webpack Loaders and Plugins
4- Creating layouts and page design
5- Service workers
6- Using APIs and creating requests to external URLs.